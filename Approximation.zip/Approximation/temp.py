import heapq
import math

# --- Helper functions for graph algorithms (for TSP) ---

def prim_mst(graph):
    """
    Computes the Minimum Spanning Tree (MST) of a graph using Prim's algorithm.
    The graph is represented as an adjacency matrix where graph[i][j] is the weight
    of the edge between vertex i and j. Infinity (float('inf')) indicates no edge.
    Returns the MST as an adjacency list.
    """
    num_vertices = len(graph)
    min_heap = [(0, 0, -1)]  # (weight, vertex, parent)
    visited = [False] * num_vertices
    mst_adj = [[] for _ in range(num_vertices)]
    total_edges_in_mst = 0

    while min_heap and total_edges_in_mst < num_vertices - 1:
        weight, u, parent = heapq.heappop(min_heap)

        if visited[u]:
            continue
        visited[u] = True

        if parent != -1:
            mst_adj[parent].append((u, weight))
            mst_adj[u].append((parent, weight))
            total_edges_in_mst += 1

        for v in range(num_vertices):
            if not visited[v] and graph[u][v] != float('inf'):
                heapq.heappush(min_heap, (graph[u][v], v, u))
    return mst_adj

def dfs_preorder_traversal(mst_adj, start_node=0):
    """
    Performs a Depth First Search (DFS) traversal on the MST
    and returns the sequence of visited nodes (pre-order traversal).
    """
    visited = [False] * len(mst_adj)
    path = []
    stack = [start_node]

    while stack:
        u = stack.pop()
        if not visited[u]:
            visited[u] = True
            path.append(u)
            # Add neighbors to stack in reverse order to process in forward order
            for v, _ in reversed(mst_adj[u]):
                if not visited[v]:
                    stack.append(v)
    return path

def find_odd_degree_vertices(mst_adj):
    """
    Finds all vertices with an odd degree in the MST.
    """
    odd_degree_vertices = []
    for i, neighbors in enumerate(mst_adj):
        if len(neighbors) % 2 != 0:
            odd_degree_vertices.append(i)
    return odd_degree_vertices

def min_weight_perfect_matching(odd_degree_vertices, graph):
    """
    A simple (and inefficient for large graphs) greedy approach to find a
    minimum weight perfect matching on the subgraph induced by odd_degree_vertices.
    For a proper Christofides, a more sophisticated algorithm (e.g., Edmonds' blossom algorithm)
    is needed. This is a simplified greedy version for demonstration.
    """
    if not odd_degree_vertices:
        return []

    # Create a subgraph with only odd-degree vertices
    subgraph_nodes = sorted(odd_degree_vertices)
    matching = []
    matched = [False] * len(subgraph_nodes)

    # Sort edges by weight and greedily pick
    edges = []
    for i in range(len(subgraph_nodes)):
        for j in range(i + 1, len(subgraph_nodes)):
            u_orig = subgraph_nodes[i]
            v_orig = subgraph_nodes[j]
            if graph[u_orig][v_orig] != float('inf'):
                edges.append((graph[u_orig][v_orig], u_orig, v_orig))
    edges.sort()

    for weight, u, v in edges:
        if not matched[subgraph_nodes.index(u)] and not matched[subgraph_nodes.index(v)]:
            matching.append((u, v))
            matched[subgraph_nodes.index(u)] = True
            matched[subgraph_nodes.index(v)] = True
            # Break if all odd-degree vertices are matched
            if all(matched):
                break
    return matching

def find_eulerian_circuit(graph_with_matching, start_node=0):
    """
    Finds an Eulerian circuit in a graph using Hierholzer's algorithm.
    The graph is represented as an adjacency list.
    Assumes the graph is Eulerian (all degrees even and connected).
    """
    num_vertices = len(graph_with_matching)
    current_path = [start_node]
    circuit = []
    # Create a copy of the adjacency list to modify (remove edges)
    temp_graph = [list(neighbors) for neighbors in graph_with_matching]

    while current_path:
        u = current_path[-1]
        if temp_graph[u]:
            # Pick an arbitrary neighbor
            v, weight = temp_graph[u].pop(0)
            # Remove the reverse edge as well
            for i, (neighbor, w) in enumerate(temp_graph[v]):
                if neighbor == u:
                    temp_graph[v].pop(i)
                    break
            current_path.append(v)
        else:
            circuit.append(current_path.pop())
    return circuit[::-1] # Reverse to get correct order

# --- 1. Travelling Salesman Approximation (Metric TSP) with 2-Approximation ---

def tsp_2_approximation(graph):
    """
    Implements the 2-approximation algorithm for Metric TSP.
    Assumes the graph satisfies the triangle inequality.
    Steps:
    1. Compute a Minimum Spanning Tree (MST).
    2. Perform a pre-order traversal (DFS) on the MST to get a tour.
    3. Remove repeated vertices from the tour to form a Hamiltonian cycle.
    """
    num_vertices = len(graph)
    if num_vertices == 0:
        return [], 0
    if num_vertices == 1:
        return [0], 0

    # Step 1: Compute MST
    mst_adj = prim_mst(graph)
    print(f"MST Adjacency List: {mst_adj}")

    # Step 2: Perform pre-order traversal on MST
    eulerian_tour = dfs_preorder_traversal(mst_adj)
    print(f"Eulerian Tour from DFS: {eulerian_tour}")

    # Step 3: Remove repeated vertices to form a Hamiltonian cycle
    hamiltonian_cycle = []
    visited_in_cycle = [False] * num_vertices
    for vertex in eulerian_tour:
        if not visited_in_cycle[vertex]:
            hamiltonian_cycle.append(vertex)
            visited_in_cycle[vertex] = True
    # Complete the cycle by returning to the start node
    if num_vertices > 1:
        hamiltonian_cycle.append(hamiltonian_cycle[0])

    # Calculate the total cost of the Hamiltonian cycle
    total_cost = 0
    for i in range(len(hamiltonian_cycle) - 1):
        u = hamiltonian_cycle[i]
        v = hamiltonian_cycle[i+1]
        cost = graph[u][v]
        if cost == float('inf'):
            print(f"Warning: Path from {u} to {v} does not exist in original graph. This indicates an issue.")
            return [], float('inf') # Should not happen if graph is connected
        total_cost += cost

    return hamiltonian_cycle, total_cost

# --- 2. Christofides’ Algorithm for TSP ---

def christofides_algorithm(graph):
    """
    Implements Christofides' algorithm for TSP (1.5-approximation).
    Assumes the graph satisfies the triangle inequality.
    Steps:
    1. Compute a Minimum Spanning Tree (MST).
    2. Find all vertices with odd degrees in the MST.
    3. Find a minimum weight perfect matching on the subgraph induced by these odd-degree vertices.
       (Note: This implementation uses a simplified greedy matching, not a true min-weight perfect matching).
    4. Combine the MST and the matching to form an Eulerian graph.
    5. Find an Eulerian circuit in this combined graph.
    6. Convert the Eulerian circuit into a Hamiltonian cycle by skipping repeated vertices.
    """
    num_vertices = len(graph)
    if num_vertices == 0:
        return [], 0
    if num_vertices == 1:
        return [0], 0

    # Step 1: Compute MST
    mst_adj = prim_mst(graph)
    print(f"Christofides - MST Adjacency List: {mst_adj}")

    # Step 2: Find odd-degree vertices in MST
    odd_vertices = find_odd_degree_vertices(mst_adj)
    print(f"Christofides - Odd Degree Vertices in MST: {odd_vertices}")

    # Step 3: Find a minimum weight perfect matching on odd-degree vertices
    # This is a simplified greedy matching for demonstration.
    matching_edges = min_weight_perfect_matching(odd_vertices, graph)
    print(f"Christofides - Matching Edges: {matching_edges}")

    # Step 4: Combine MST and matching to form an Eulerian graph
    eulerian_graph_adj = [list(neighbors) for neighbors in mst_adj]
    for u, v in matching_edges:
        weight = graph[u][v]
        eulerian_graph_adj[u].append((v, weight))
        eulerian_graph_adj[v].append((u, weight))
    print(f"Christofides - Eulerian Graph Adjacency List: {eulerian_graph_adj}")

    # Step 5: Find an Eulerian circuit
    # Ensure the graph is connected and all degrees are even for Eulerian circuit
    # (This is guaranteed by Christofides' construction)
    eulerian_circuit_path = find_eulerian_circuit(eulerian_graph_adj, start_node=0)
    print(f"Christofides - Eulerian Circuit Path: {eulerian_circuit_path}")

    # Step 6: Convert Eulerian circuit to Hamiltonian cycle by skipping repeated vertices
    hamiltonian_cycle = []
    visited_in_cycle = [False] * num_vertices
    for vertex in eulerian_circuit_path:
        if not visited_in_cycle[vertex]:
            hamiltonian_cycle.append(vertex)
            visited_in_cycle[vertex] = True
    # Complete the cycle by returning to the start node
    if num_vertices > 1 and hamiltonian_cycle and hamiltonian_cycle[0] != hamiltonian_cycle[-1]:
        hamiltonian_cycle.append(hamiltonian_cycle[0])

    # Calculate total cost
    total_cost = 0
    for i in range(len(hamiltonian_cycle) - 1):
        u = hamiltonian_cycle[i]
        v = hamiltonian_cycle[i+1]
        cost = graph[u][v]
        if cost == float('inf'):
            print(f"Warning: Path from {u} to {v} does not exist in original graph. This indicates an issue.")
            return [], float('inf')
        total_cost += cost

    return hamiltonian_cycle, total_cost

# --- 3. Set Cover (Greedy Algorithm) ---

def greedy_set_cover(universe, subsets):
    """
    Implements the greedy algorithm for the Set Cover problem.
    Given a universe of elements and a collection of subsets, find the
    smallest collection of subsets whose union is the universe.
    """
    covered_elements = set()
    solution_sets = []
    uncovered_elements = set(universe)

    while uncovered_elements:
        best_set = None
        max_new_elements_covered = -1

        for s_name, s_elements in subsets.items():
            current_set_elements = set(s_elements)
            # Find elements in current_set_elements that are not yet covered
            newly_covered = current_set_elements.intersection(uncovered_elements)
            num_new_elements = len(newly_covered)

            if num_new_elements > max_new_elements_covered:
                max_new_elements_covered = num_new_elements
                best_set = s_name

        if best_set is None:
            # This should not happen if a cover exists
            print("Warning: No set found to cover remaining elements. Universe may not be coverable.")
            break

        solution_sets.append(best_set)
        covered_elements.update(set(subsets[best_set]))
        uncovered_elements = universe.difference(covered_elements) # Re-calculate uncovered

    return solution_sets, len(solution_sets)

# --- 4. Greedy Algorithm (General Example: Coin Change) ---

def greedy_coin_change(amount, denominations):
    """
    A general example of a greedy algorithm: Coin Change problem.
    Given an amount and a list of coin denominations (sorted in descending order),
    find the minimum number of coins to make up the amount.
    This greedy approach works optimally only for certain coin systems (e.g., US currency).
    """
    denominations.sort(reverse=True) # Ensure denominations are sorted descending
    coins_used = {}
    remaining_amount = amount

    for coin in denominations:
        if remaining_amount >= coin:
            num_coins = remaining_amount // coin
            coins_used[coin] = num_coins
            remaining_amount -= num_coins * coin
        if remaining_amount == 0:
            break

    if remaining_amount > 0:
        print(f"Warning: Cannot make exact change for {amount} with given denominations.")
        return {}, -1 # Indicate failure

    total_coins = sum(coins_used.values())
    return coins_used, total_coins

# --- Example Usage ---

if __name__ == "__main__":
    print("--- Metric TSP 2-Approximation Example ---")
    # Example graph (adjacency matrix)
    # 0 --1-- 1
    # | \     |
    # 3   \   2
    # |     \ |
    # 2 --4-- 3
    # This graph satisfies triangle inequality: dist(a,c) <= dist(a,b) + dist(b,c)
    # For example, dist(0,3) = 5. dist(0,1)+dist(1,3) = 1+2 = 3. This doesn't satisfy.
    # Let's use a graph that ensures triangle inequality (e.g., Euclidean distances)
    # For simplicity, I'll define a graph that *should* work with the approximation,
    # but for true metric TSP, coordinates and Euclidean distances are best.

    # A simple 4-node complete graph satisfying triangle inequality
    # (e.g., distances derived from coordinates)
    # Node 0: (0,0)
    # Node 1: (1,0)
    # Node 2: (0,1)
    # Node 3: (1,1)
    # Distances:
    # 0-1: 1
    # 0-2: 1
    # 0-3: sqrt(2) approx 1.41
    # 1-2: sqrt(2) approx 1.41
    # 1-3: 1
    # 2-3: 1
    graph_tsp = [
        [0, 1, 1, 1.41],
        [1, 0, 1.41, 1],
        [1, 1.41, 0, 1],
        [1.41, 1, 1, 0]
    ]
    # Fill infinity for non-existent edges if not a complete graph
    # For TSP, it's usually a complete graph or we use infinity for non-edges.
    # Here, it's a complete graph.

    path_2_approx, cost_2_approx = tsp_2_approximation(graph_tsp)
    print(f"\n2-Approximation TSP Path: {path_2_approx}")
    print(f"2-Approximation TSP Cost: {cost_2_approx:.2f}")

    print("\n--- Christofides’ Algorithm Example ---")
    # Using the same graph_tsp as it's metric
    path_christofides, cost_christofides = christofides_algorithm(graph_tsp)
    print(f"\nChristofides TSP Path: {path_christofides}")
    print(f"Christofides TSP Cost: {cost_christofides:.2f}")

    print("\n--- Greedy Set Cover Example ---")
    universe_elements = {'A', 'B', 'C', 'D', 'E', 'F', 'G'}
    available_subsets = {
        'S1': {'A', 'B', 'C'},
        'S2': {'C', 'D', 'E'},
        'S3': {'E', 'F'},
        'S4': {'D', 'G'},
        'S5': {'A', 'G'}
    }
    solution_sets, num_sets = greedy_set_cover(universe_elements, available_subsets)
    print(f"Universe: {universe_elements}")
    print(f"Available Subsets: {available_subsets}")
    print(f"Greedy Set Cover Solution: {solution_sets}")
    print(f"Number of Sets in Cover: {num_sets}")

    print("\n--- Greedy Coin Change Example ---")
    amount_to_change = 63
    denominations_us = [25, 10, 5, 1] # US currency
    coins_used_us, total_coins_us = greedy_coin_change(amount_to_change, denominations_us)
    print(f"Amount: {amount_to_change}, Denominations: {denominations_us}")
    print(f"Coins Used (US): {coins_used_us}, Total Coins: {total_coins_us}")

    amount_to_change_non_optimal = 30
    denominations_non_optimal = [25, 20, 10, 5, 1] # Example where greedy might not be optimal (e.g., 20+10 vs 25+5)
    coins_used_non_optimal, total_coins_non_optimal = greedy_coin_change(amount_to_change_non_optimal, denominations_non_optimal)
    print(f"\nAmount: {amount_to_change_non_optimal}, Denominations: {denominations_non_optimal}")
    print(f"Coins Used (Non-optimal Greedy): {coins_used_non_optimal}, Total Coins: {total_coins_non_optimal}")
    # For 30, optimal is [20, 10] (2 coins). Greedy gives [25, 5] (2 coins) - in this case, it's still optimal.
    # Let's try 40 with [25, 20, 10, 5, 1]
    # Greedy: 25 + 10 + 5 = 40 (3 coins)
    # Optimal: 20 + 20 = 40 (2 coins)
    amount_to_change_non_optimal_2 = 40
    denominations_non_optimal_2 = [25, 20, 10, 5, 1]
    coins_used_non_optimal_2, total_coins_non_optimal_2 = greedy_coin_change(amount_to_change_non_optimal_2, denominations_non_optimal_2)
    print(f"\nAmount: {amount_to_change_non_optimal_2}, Denominations: {denominations_non_optimal_2}")
    print(f"Coins Used (Non-optimal Greedy Example): {coins_used_non_optimal_2}, Total Coins: {total_coins_non_optimal_2}")
